package appiumtests;



import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Interaction;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class eCommerceApp {
	

	public static AppiumDriver driver=null;
	public static DesiredCapabilities cap= new DesiredCapabilities();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			openApp();
			scenarioOne();


		}
	catch(Exception exp){
		exp.getCause();
		exp.getMessage();
			}
		

	}
	

	
	 private static void tap(AppiumDriver driver, WebElement element) {
		    Point location = element.getLocation();
		    Dimension size = element.getSize();

		    Point centerOfElement = getCenterOfElement(location, size);

		    PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
		    Sequence sequence = new Sequence(finger1, 1)
		        .addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerOfElement))
		        .addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
		        .addAction(new Pause(finger1, Duration.ofMillis(200)))
		        .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

		    driver.perform(Collections.singletonList(sequence));
		  }

		  private static Point getCenterOfElement(Point location, Dimension size) {
		    return new Point(location.getX() + size.getWidth() / 2,
		                     location.getY() + size.getHeight() / 2);
		  }


//		  private static Capabilities cap() {
//			//device info
//			cap.setCapability("appium:deviceName", "V94");
//			cap.setCapability("appium:udid", "LAAP1909003552");
//			cap.setCapability("appium:platformName", "Android");
//			cap.setCapability("appium:platformVersion", "8.1.0");
//			
//			cap.setCapability("appium:appPackage", "com.nopstation.nopcommerce.nopstationcart");
//			cap.setCapability("appium:appActivity", "com.bs.ecommerce.main.SplashScreenActivity");	
//			cap.setCapability("appium:noReset", true);
//			cap.setCapability("appium:automationName", "UiAutomator2");
//			cap.setCapability("appium:ignoreHiddenApiPolicyError", true);
//			return cap;
//		  }
//	
	
	
	@SuppressWarnings("deprecation")
	public static void openApp() {

		cap.setCapability("appium:deviceName", "V94");
		cap.setCapability("appium:udid", "LAAP1909003552");
		cap.setCapability("appium:platformName", "Android");
		cap.setCapability("appium:platformVersion", "8.1.0");
		
		cap.setCapability("appium:appPackage", "com.nopstation.nopcommerce.nopstationcart");
		cap.setCapability("appium:appActivity", "com.bs.ecommerce.main.SplashScreenActivity");	
		cap.setCapability("appium:noReset", true);
		cap.setCapability("appium:automationName", "UiAutomator2");
		cap.setCapability("appium:ignoreHiddenApiPolicyError", true);
	
		//cap.setCapability("appium:autoGrantPermissions", true);
		//cap.setCapability("androidInstallTimeout", "180000");
		
		//sdriver=new AppiumDriver<MobileElement>(urL, cap);
		try {
		URL urL=new URL("http://127.0.0.1:4723/wd/hub");
			 driver = new AndroidDriver(urL, cap);
			 System.out.println("App Started");
			// String sessionId=driver.getSessionId().toString();

			} catch (Exception e) {

			System.out.println(e.getMessage());

			}}
		
		
		
	public static void scenarioOne() {

	  
	   try {
		   
			//URL urL=new URL("http://127.0.0.1:4723/wd/hub");
			// driver = new AndroidDriver(urL, cap());
		  // driver.startActivity("com.nopstation.nopcommerce.nopstationcart", "com.bs.ecommerce.main.MainActivity");
		   //still sometime on homepage
		   System.out.println("this is Homepage");
		  // WebElement homee =subdriver.findElement(By.xpath("//*[@text='NopStation Cart']"));
		  // homee.click();
		 //Thread.sleep(3000);
		   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		   
		   System.out.println("this is Product (Electronincs) click");
		 //  PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
	       // Sequence tap = new Sequence(finger, 1);
	//	WebElement element1 =	 driver.findElement(AppiumBy.xpath("//*[@id='ivProductThumb' and ./parent::*[@id='card' and (./preceding-sibling::* | ./following-sibling::*)[@text='Electronics']]]")).click();

		// tap(driver, element1);
		   
		 
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}


	
}
